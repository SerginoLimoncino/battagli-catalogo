const { app, BrowserWindow, Menu, session, shell } = require('electron');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, 'www');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.wasm': 'application/wasm', '.tflite': 'application/octet-stream', '.json': 'application/json', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.gz': 'application/gzip', '.traineddata': 'application/octet-stream' };
const PORT = 38417; // fixed so the saved catalogue (IndexedDB) stays on the same origin
function serve() {
  return new Promise(res => {
    const srv = http.createServer((req, rsp) => {
      let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.normalize(path.join(ROOT, p));
      if (!f.startsWith(ROOT)) { rsp.writeHead(403); return rsp.end(); }
      fs.readFile(f, (e, d) => {
        if (e) { rsp.writeHead(404); return rsp.end(); }
        rsp.writeHead(200, { 'Content-Type': TYPES[path.extname(f).toLowerCase()] || 'application/octet-stream' }); rsp.end(d);
      });
    });
    srv.on('error', () => srv.listen(0, '127.0.0.1', () => res(srv.address().port)));
    srv.listen(PORT, '127.0.0.1', () => res(PORT));
  });
}
app.whenReady().then(async () => {
  const port = await serve();
  Menu.setApplicationMenu(null);
  const ok = ['fullscreen', 'clipboard-read', 'clipboard-sanitized-write'];
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(ok.includes(perm)));
  const win = new BrowserWindow({ width: 1180, height: 860, minWidth: 420, minHeight: 600, title: 'Battagli Marine Hardware', autoHideMenuBar: true, backgroundColor: '#ffffff', icon: path.join(__dirname, 'icon.png'), webPreferences: { backgroundThrottling: false } });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(tel|mailto|https?):/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('http://127.0.0.1:' + port)) { e.preventDefault(); if (/^(tel|mailto|https?):/.test(url)) shell.openExternal(url); } });
  win.loadURL('http://127.0.0.1:' + port + '/index.html');
});
app.on('window-all-closed', () => app.quit());
